package com.example.CustomerCrud.Repository;

import java.sql.SQLException;
import java.util.List;

import com.example.CustomerCrud.Model.CustomerModel;

public interface CustomerRepository {
	
	public String RepositoryMethod(CustomerModel modelobj);
	public void deletecustomer(int cusid)throws SQLException;
	public void updatecustomer(int cusid,String cusemail,String cusname,int cusno)throws SQLException;
	public CustomerModel getcustomer(int cusid)throws Exception;
	public List<CustomerModel> getallcustomer()throws Exception;

}

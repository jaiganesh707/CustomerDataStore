package com.example.CustomerCrud.Service;

import java.util.List;

import com.example.CustomerCrud.Model.CustomerModel;

public interface CustomerService {
	
	public String customerServiceMethod(CustomerModel uiux)throws Exception;
	public void deletecustomer(int cusid)throws Exception;
	public void updatecustomer(int cusid,String cusemail,String cusname,int cusno)throws Exception;
	public CustomerModel getcustomer(int cusid)throws Exception;
	public List<CustomerModel> getallcustomer()throws Exception;


}

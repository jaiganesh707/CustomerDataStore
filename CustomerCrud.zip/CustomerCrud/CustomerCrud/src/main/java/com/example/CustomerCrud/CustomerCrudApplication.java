package com.example.CustomerCrud;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import com.example.CustomerCrud.Model.CustomerModel;
import com.example.CustomerCrud.Service.CustomerService;

@SpringBootApplication
public class CustomerCrudApplication implements CommandLineRunner {
	@Autowired
	private CustomerService customerservice;
	
	@Autowired
	private Environment environment;
	public static void main(String[] args) {
		SpringApplication.run(CustomerCrudApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		
		try {
		
		CustomerModel uiuxmod=new CustomerModel();
		uiuxmod.setCusid(004);
		uiuxmod.setCusemail("jaiganeshjkm@gmail.com");
		uiuxmod.setCusname("bord");
		uiuxmod.setCusno(135790);
	String customername=customerservice.customerServiceMethod(uiuxmod);
		System.out.println(customername);
		
		} catch (Exception e) {
			// TODO: handle exception
			if(e.getMessage()!=null) {
				System.out.println(e.getMessage());
			}
		}
		
		
		/*
		try {
			customerservice.deletecustomer(3);
			System.out.println("successfully deleted");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("not deleted");
		}
		
		try {
			customerservice.updatecustomer(001, "jaiganeshjkm@gmail.com", "jaiganesh", 70942617);
			System.out.println("update customer values");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("NOT updated NOT");
		}
				*/
		/*
		try {
			CustomerModel customer=customerservice.getcustomer(4);
			System.out.println(customer.getCusno());
			System.out.println(customer.getCusname());
			System.out.println(customer.getCusemail());
		} catch (Exception e) {
			// TODO: handle exception
			
			if(e.getMessage()!=null) {
			System.out.println(e.getMessage());
		}}
	*/	
//		List<CustomerModel> customer=customerservice.getallcustomer();
	//	for (CustomerModel cus : customer) {
		//	System.out.println("CustomerNo:"+cus.getCusno());
	//		System.out.println("CustomerName:"+cus.getCusname());
	//		System.out.println("CustomerEmail:"+cus.getCusemail());	
	//	}

		
	}
	
}
